<?php
include_once "DepartmentModel.php";
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class DepartmentController
{
    function getRow()
    {
        
        $para=  func_get_args();
        $obj=new DepartmentModel();
        $result = $obj->getRow($para[0]);
	return $result;
   }
   
   
   function fetchDepartmentData()
  {
	$arg=func_get_args();
    $obj=new DepartmentModel();
	if($arg)
	{
		$arr=$obj->fetchDepartmentTable($arg[0]);
	}
	else
	{
		$arr=$obj->fetchDepartmentTable();
	}
	return($arr);
  }
}



?>