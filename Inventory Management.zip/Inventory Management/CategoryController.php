<?php
include_once "CategoryModel.php";
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 */
class CategoryController
{
function selectAllCategories()
    {
        $categoryObj=new CategoryModel();
        return $categoryObj->selectAllCategories();
    }
       function categoryList()
    {
         $para=func_get_args();
        $obj=new CategoryModel();
        return $obj->categoryList($para[0]);
    }
	
		function getAllCategories()
	{
		$categoryModelObj=new CategoryModel();
		$result=$categoryModelObj->fetchAllCategories();
		$index=0;
		$array="";
		while($row=mysqli_fetch_array($result))
		{
			$array[$index] = $row;
			$index++;
		}
		return $array;
	}

    function getVendorCategory()
	{
		$categoryModelObj=new CategoryModel();
		$result=$categoryModelObj->fetchVendorCategory(func_get_arg(0));
        if(is_bool($result))
            return NULL;
		$index=0;
		$array=NULL;
		while($row=mysqli_fetch_array($result))
		{
			$array[$index] = $row;
			$index++;
		}
		return $array;
	}

	function getCategoryName()
    {
        $catModelObj=new CategoryModel();
        $result=$catModelObj->fetchCategoryName(func_get_arg(0));
        if(!is_bool($result) && !is_null($result))
		{
            $row=mysqli_fetch_array($result);
            return $row;
        }
        else
            return NULL;
    }

	
	function getCategory()
{
$categoryModelObj=new CategoryModel();
	$result=$categoryModelObj->fetchAllCategoryData();
	if($result)
	{
	   
	    return $result;
	}
	else
	{
	//echo"wrong in controller";
	    return false;
	}
}
function getCategoryReport()
	{
		$item="";
		$i=0;
		$arg = func_get_args();
                $obj=new CategoryModel();
		$result = $obj->fetchCategoryReport($arg[0]);
		while($row=mysqli_fetch_array($result))
		{
			if($i==0)
			{
				$item.=$row[0]." ";	
			}
			else
				$item.=" or `item_id`=".$row[0];
			$i++;
		}
                
		return $item;
	}
	

}
?>