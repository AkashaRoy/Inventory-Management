<?php
 session_start();
include_once 'template.php';
include_once 'StockUI.php';
include_once 'POController.php';
include_once 'ItemController.php';
include_once 'StockController.php';
include_once 'CategoryController.php';
$StockUIobj=new StockUI();
$temp=$_SESSION['po'];
//echo $temp;
if(empty($_POST) || !isset($_POST))
	    {
		$res= $StockUIobj->requestForm();
		//echo $res;
		echo"</br><table  align='center'><tr><td><h2>$res<h2></td></tr></table>";
		//echo"</br><a href='database.php'>want to enter again</a></br>";
	    }
	    else
	    {
		
		$r=$StockUIobj->onReceiveFormDataSubmit();
		if($r)
		{
		while($row=mysqli_fetch_array($r))
	    {
		echo "</br>";
		echo "<h3 align='center'>DETAILS OF ITEM STORED</h3>
	<table align='center' border=2><tr></tr>
			<tr>
	<td>stock id</td>
	<td>purchase order id</td>
	<td>item id</td>
	<td>quantity</td>
	<td>current stock</td>
	<td>damaged goods</td>
	<td>received date</td>
	<td>category</td>
</tr>";
	echo"<tr>
	<td>$row[0]</td>
	<td>$row[1]</td>
	<td>$row[2]</td>
	<td>$row[4]</td>
	<td>$row[5]</td>
	<td>$row[9]</td>
	<td>$row[7]</td>
	<td>$row[8]</td>
	</tr>";
	echo "</table>";
		}
		echo "<div align='center'>
	<a href='database_stock.php' ><button>enter again</button></a></br>
 
 </div>";
		}
		else 
		{
		echo"<table  align='center'><tr><td><h2><font color='red'>sorry try again</font><h2></td></tr></table>";
		}
		}

include_once 'footer.php';
?>