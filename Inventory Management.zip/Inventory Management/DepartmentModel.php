<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 */
class DepartmentModel
{
    function getRow()
    {
        
         $para=  func_get_args();
        $con=mysqli_connect("localhost","root","","vocational_training");
        $query="SELECT * FROM `department` where department_id=".$para[0];
        $result=mysqli_query($con,$query);
	return $result;
    }
	
	
	function fetchDepartmentTable()
  {
	$arg=func_get_args();
    $con=mysqli_connect("localhost","root","","vocational_training");
	$index=0;
	$return_array;
	if($arg)
	{
		$query="SELECT * FROM `department` where department_id='$arg[0]'";
		$res=mysqli_query($con,$query);
        $return_array = '';
		while($row=mysqli_fetch_array($res))
		{
		  $return_array[$index] = $row[1]; 
			
		  $index++;
		}
		return $return_array;  	  
	}
	else
	{
		$query="SELECT * FROM `department`";
		$res=mysqli_query($con,$query);
		while($row=mysqli_fetch_array($res))
		{
		  $return_array[$index] = $row[0]; 
		  $index++;
		  $return_array[$index] = $row[1]; 
		  $index++;
		}
		return $return_array; 
	}	
   }

}
?>