<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<script type="text/javascript" src="Vendor.js"></script>
        <title></title>
		
		
		
    </head>
    

	
<?php
	//include_once'vendor.php';
    include_once'VendorUI.php';
	include_once 'template.php';
	
	$vendorUIObj=new VendorUI();
	if (isset($_POST)&&!empty($_POST))
	{
	    echo  $vendorUIObj->onDisplayVendorFormSubmit();
	}
	else {
	    echo  $vendorUIObj->displayVendorForm(); 
		
	}
	 include_once 'footer.php';
         
?>