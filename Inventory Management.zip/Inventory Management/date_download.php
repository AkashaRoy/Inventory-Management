<?php
include_once 'config/Classes/PHPExcel.php';
include_once 'config/Classes/PHPExcel/IOFactory.php';
include_once 'StockModel.php';
$code=$_GET['id'];
//echo $code;
$stockModelObj2=new StockModel();
$r=$stockModelObj2->fetchrequestAllItemCurrentStock($code);
$obj = new PHPExcel();
$obj->createSheet();
$obj->getActiveSheet()->setCellValue('A1', 'expected date');
$obj->getActiveSheet()->setCellValue('B1', 'purchase order id');
$obj->getActiveSheet()->setCellValue('C1', 'status');
$obj->getActiveSheet()->setCellValue('D1', 'item id');
$obj->getActiveSheet()->setCellValue('E1', 'quantity');
$obj->getActiveSheet()->setCellValue('F1', 'receive date');

$t=2;
while($row=mysqli_fetch_array($r)){
	$obj->getActiveSheet()->setCellValue('A'.$t,$row[0]);
	$obj->getActiveSheet()->setCellValue('B'.$t,$row[1]);
	$obj->getActiveSheet()->setCellValue('C'.$t,$row[2]);
	$obj->getActiveSheet()->setCellValue('D'.$t,$row[3]);
	$obj->getActiveSheet()->setCellValue('E'.$t,$row[4]);
	$obj->getActiveSheet()->setCellValue('F'.$t,$row[5]);
	$t++;
}
$objWriter = PHPExcel_IOFactory::createWriter($obj, 'Excel2007');
header('Content-type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="Test_File.xls"');
$objWriter->save('php://output');
?>