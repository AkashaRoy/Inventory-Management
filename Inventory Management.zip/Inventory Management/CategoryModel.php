<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class CategoryModel
{
function selectAllCategories()
    {
        $con=mysqli_connect("localhost","root","","vocational_training");
		$query="SELECT * FROM `category`";
		$result=mysqli_query($con,$query);
		return $result;
    }
       function categoryList()
    {
        $para=  func_get_args();
        $num=  func_num_args();
        $host='localhost';
        $user='root';
        $password='';
        $database='vocational_training';
        $link=  mysqli_connect($host, $user, $password, $database);
        if($num==1)
        {
        $query="select * from category where category_id=".$para[0];    
        }
        $res=  mysqli_query($link, $query);
        if($res)
            return $res;
        else
            return false;
    }
	
	function fetchAllCategoryData()
{
$host = 'localhost';
	$user = 'root';
	$password = '';
	$database = 'vocational_training';
	$link = mysqli_connect($host, $user, $password, $database);
	$query="select distinct name from category";
	//echo $query;
	$res = mysqli_query($link, $query);
	//var_dump($res);
	
	if($res)
	{
	//echo"<br/>item exist";
	    return $res;
		}
	else{
	//echo " <br/>item does not exist in model";
	    return false;
	}

}

function fetchAllCategories()
	{
		$con=mysqli_connect("localhost","root","","vocational_training");
		$query="SELECT * FROM `category`";
		$result=mysqli_query($con,$query);
		return $result;
	}
	
    function fetchVendorCategory()
	{
        $arg = func_get_arg(0);
		$con=mysqli_connect("localhost","root","","vocational_training");
		$query="SELECT `category_id` FROM `category_vendor` WHERE `vendor_id`=$arg";
		$result=mysqli_query($con,$query);
		return $result;
	}

    function fetchCategoryName()
    {
		$catID=func_get_arg(0);
        $con=mysqli_connect("localhost","root","","vocational_training");
        $query="SELECT `name` FROM `category` WHERE `category_id`=$catID";
        $result=mysqli_query($con,$query);
		return $result;
    }
	function fetchCategoryReport()//function to be added in CategoryModel
	{
		$arg=func_get_args();
		$host = 'localhost';
		$user = 'root';
		$password = '';
		$database = 'vocational_training';
		$link = mysqli_connect($host, $user, $password, $database);
		$query = "SELECT `item_id` FROM `item` WHERE `category_id`='".$arg[0]."'";
		$result=mysqli_query($link,$query);
		return $result;
	}
	
	
	
}
?>