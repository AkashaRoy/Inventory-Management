<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<script type="text/javascript" src="Vendor.js"></script>
		

		
        <title>Add Vendor</title>
    </head>
    
<?php
	include_once 'VendorUI.php';
	//include_once'vendor.php';
	include_once 'template.php';
	
	
	$vendorUIObj=new VendorUI();
	if (isset($_POST)&&!empty($_POST))
	{
	    echo  $vendorUIObj->onAddVendorFormSubmit();
	}
	else {
	  
	 echo  '<br><br><h3 style="text-align:center;"><font color="black">Fields which are marked <font color="red">*</font> are mandatory.</font></h3>';
	  echo  $vendorUIObj->addVendorForm();
		
	}
	 include_once 'footer.php';
?>

    
</html>