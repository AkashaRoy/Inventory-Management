<html>
<head>
    <script type="text/javascript" src="Vendor.js"></script>
	

		
    <title>Edit Vendor</title>
</head>

<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

    include_once 'VendorUI.php';
    //include_once'Vendor.php';
	include_once 'template.php';
	 
    $vendorUIObj = new VendorUI();
    if(!isset($_POST) || empty($_POST))
    {
        echo  $vendorUIObj->editVendorForm();	
    }
    else if(isset ($_GET['form']) && $_GET['form']=="submit")
    {
        echo $vendorUIObj->editVendor();
	
    }
    else
    {
        echo  $vendorUIObj->onEditVendorFormSubmit();
	 
    }
include_once 'footer.php';
	
?>
</html>